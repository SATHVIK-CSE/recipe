# Recipe Organizer — Cloudflare Workers + D1 Backend

## Setup Steps
1. Create a D1 database in Cloudflare Dashboard (**Storage & Databases > D1 SQL Database > Create**) named `recipe-db`.
2. Copy its **Database ID** into `wrangler.jsonc` (`database_id`).
3. Run the SQL in `schema.sql` in the D1 **Console** tab to create the `recipes` table.
4. Push all files (`wrangler.jsonc`, `schema.sql`, `src/worker.js`, and `public/index.html`) to your GitHub repo (`SATHVIK-CSE/recipe`)—Cloudflare will automatically build and deploy both the website and the `/api/recipes` backend.
