export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === "/api/recipes" && request.method === "GET") {
      const { results } = await env.DB.prepare(
        "SELECT id, name, meal, prep_time AS prepTime, servings, ingredients, steps FROM recipes ORDER BY created_at DESC"
      ).all();

      const recipes = results.map((row) => ({
        ...row,
        ingredients: JSON.parse(row.ingredients),
        steps: JSON.parse(row.steps),
      }));

      return Response.json(recipes);
    }

    if (url.pathname === "/api/recipes" && request.method === "POST") {
      const body = await request.json();
      const id = "r_" + Date.now();
      const name = String(body.name || "").trim();
      const meal = String(body.meal || "Dinner").trim();
      const prepTime = Math.max(1, parseInt(body.prepTime, 10) || 20);
      const servings = Math.max(1, parseInt(body.servings, 10) || 2);
      const ingredients = Array.isArray(body.ingredients) ? body.ingredients : [];
      const steps = Array.isArray(body.steps) ? body.steps : [];

      if (!name || ingredients.length === 0 || steps.length === 0) {
        return Response.json({ error: "Name, ingredients, and steps are required." }, { status: 400 });
      }

      await env.DB.prepare(
        "INSERT INTO recipes (id, name, meal, prep_time, servings, ingredients, steps, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
      )
        .bind(id, name, meal, prepTime, servings, JSON.stringify(ingredients), JSON.stringify(steps), Date.now())
        .run();

      return Response.json({ id, name, meal, prepTime, servings, ingredients, steps }, { status: 201 });
    }

    if (url.pathname.startsWith("/api/recipes/") && request.method === "DELETE") {
      const id = url.pathname.replace("/api/recipes/", "");
      await env.DB.prepare("DELETE FROM recipes WHERE id = ?").bind(id).run();
      return Response.json({ deleted: true, id });
    }

    return env.ASSETS.fetch(request);
  },
};
